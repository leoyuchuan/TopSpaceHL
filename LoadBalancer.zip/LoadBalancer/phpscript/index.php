<?php
    echo '<script>window.location="../home.php"</script>';
?>

