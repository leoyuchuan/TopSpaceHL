A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/xbwBmx.

 Inspired by 
http://dribbble.com/shots/655650-Login/attachments/56946

I have used HTML5 input attribute "require" to make filed mandatory.

Forked from [Jitendra](http://codepen.io/berdejitendra/)'s Pen [Log in Form ](http://codepen.io/berdejitendra/pen/KxmvD/).